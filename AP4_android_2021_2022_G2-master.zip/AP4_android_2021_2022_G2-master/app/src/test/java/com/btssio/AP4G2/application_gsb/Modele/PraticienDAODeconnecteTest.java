package com.btssio.AP4G2.application_gsb.Modele;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by dessaigne on 17/01/2022.
 */
public class PraticienDAODeconnecteTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getPraticiens() throws Exception {
    }

    @Test
    public void getPraticiensByDepartement() throws Exception {
    }

    @Test
    public void getPraticiensByDepartement1() throws Exception {
    }

    @Test
    public void getPraticiensByNom() throws Exception {
    }

    @Test
    public void addPraticien() throws Exception {
    }

    @Test
    public void cursorToPraticienArrayList() throws Exception {
    }

    @Test
    public void addNumDepartementPraticien() throws Exception {
    }

}