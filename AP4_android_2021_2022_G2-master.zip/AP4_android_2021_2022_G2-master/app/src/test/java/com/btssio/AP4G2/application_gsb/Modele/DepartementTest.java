package com.btssio.AP4G2.application_gsb.Modele;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;

import static org.junit.Assert.*;

/**
 * Created by dessaigne on 10/01/2022.
 */
public class DepartementTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getNUM_DEPARTEMENT() throws Exception {
    }

    @Test
    public void setNUM_DEPARTEMENT() throws Exception {
    }

    @Test
    public void getNOM() throws Exception {
    }

    @Test
    public void setNOM() throws Exception {
    }

    /*@Test
    public void toString() throws Exception {
    }*/

}